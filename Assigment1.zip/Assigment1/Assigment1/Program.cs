﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment1
{
    class Program
    {
        static void Main(String[] args)
        {
            string userInput = "";
            bool givenMenu = false;
            string g = string.Empty;
            while (givenMenu == false)
            {
                Console.WriteLine("1 = Enter dimensions of Triangle");
                Console.WriteLine("2 = Exit \n");
                Console.WriteLine("Please select an option\n");
                userInput = Console.ReadLine();
                if (userInput != "1" && userInput != "2")
                {
                    Console.WriteLine("That's not a valid menu option, please try again:\n");
                }
                else if (userInput == "1")
                {
                    Console.WriteLine("...............Enter three sides of traingle................");
                    Console.WriteLine("Enter First side of triangle: ");
                    int a = int.Parse(Console.ReadLine());
                    Console.WriteLine("Enter Second Side of traingle : ");
                    int b = int.Parse(Console.ReadLine());
                    Console.WriteLine("Enter Third Side of traingle : ");
                    int c = int.Parse(Console.ReadLine());
                    g = TriangleSolver.Analyze(a, b, c);
                    Console.WriteLine("{0}", g);
                }
                else
                {
                    givenMenu = true;
                    break;
                }
            }
        }
    }
}