﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Assignment1;
using NUnit.Framework;

namespace Assignment1_tests
{
    [TestFixture]
    class Assignment1_tests
    {
        [Test]
        public static void Analyze_ainput5_binput5_cinput10_Outputnotatriangle()
        {
            //Arrange
            int a = 5;
            int b = 5;
            int c = 10;
            string result = TriangleSolver.Analyze(a, b, c);
            string expectedoutput = result;

            //Act
            string actualresult = "Given inputs doesn't form a triangle.";

            //Assert
            Assert.AreEqual(expectedoutput, actualresult);
        }
        [Test]
        public void Analyze_ainput10_binput10_cinput10_OutputEquilateral()
        {
            //Arrange
            int a = 10;
            int b = 10;
            int c = 10;
            string result = TriangleSolver.Analyze(a, b, c);
            string expectedoutput = result;

            //Act
            string actualresult = "Triangle is Equilateral.";

            //Assert
            Assert.AreEqual(expectedoutput, actualresult);
        }
        [Test]
        public void Analyze_ainput8_binput8_cinput10_OutputIsosceles()
        {
            //Arrange
            int a = 8;
            int b = 8;
            int c = 10;
            string result = TriangleSolver.Analyze(a, b, c);
            string expectedoutput = result;

            //Act
            string actualresult = "Triangle is Isosceles.";

            //Assert
            Assert.AreEqual(expectedoutput, actualresult);
        }
        [Test]
        public void Analyze_ainput11_binput16_cinput20_OutputScalene()
        {
            //Arrange
            int a = 11;
            int b = 16;
            int c = 20;
            string result = TriangleSolver.Analyze(a, b, c);
            string expectedoutput = result;

            //Act
            string actualresult = "Triangle is Scalene.";

            //Assert
            Assert.AreEqual(expectedoutput, actualresult);

        }
        [Test]
        public void Analyze_ainput11_binput11_cinput22_Outputnotatriangle()
        {
            //Arrange
            int a = 11;
            int b = 11;
            int c = 22;
            string result = TriangleSolver.Analyze(a, b, c);
            string expectedoutput = result;

            //Act
            string actualresult = "Given inputs doesn't form a triangle.";

            //Assert
            Assert.AreEqual(expectedoutput, actualresult);
        }
        [Test]
        public void Analyze_ainput20_binput20_cinput20_OutputEquilateral()
        {
            //Arrange
            int a = 20;
            int b = 20;
            int c = 20;
            string result = TriangleSolver.Analyze(a, b, c);
            string expectedoutput = result;

            //Act
            string actualresult = "Triangle is Equilateral.";

            //Assert
            Assert.AreEqual(expectedoutput, actualresult);
        }
        [Test]
        public void Analyze_ainput60_binput70_cinput60_OutputIsosceles()
        {
            //Arrange
            int a = 60;
            int b = 70;
            int c = 60;
            string result = TriangleSolver.Analyze(a, b, c);
            string expectedoutput = result;

            //Act
            string actualresult = "Triangle is Isosceles.";

            //Assert
            Assert.AreEqual(expectedoutput, actualresult);
        }
        [Test]
        public void Analyze_ainput30_binput36_cinput20_OutputScalene()
        {
            //Arrange
            int a = 30;
            int b = 36;
            int c = 20;
            string result = TriangleSolver.Analyze(a, b, c);
            string expectedoutput = result;

            //Act
            string actualresult = "Triangle is Scalene.";

            //Assert
            Assert.AreEqual(expectedoutput, actualresult);

        }
    }
}